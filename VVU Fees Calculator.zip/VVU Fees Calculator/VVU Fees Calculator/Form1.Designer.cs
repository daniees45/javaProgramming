﻿namespace VVU_Fees_Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtHours = new TextBox();
            groupBox1 = new GroupBox();
            radioNormal = new RadioButton();
            radioProject = new RadioButton();
            groupBox2 = new GroupBox();
            radioDistance = new RadioButton();
            radioSandwich = new RadioButton();
            radioRegular = new RadioButton();
            listDepartment = new ListBox();
            groupBox3 = new GroupBox();
            radioForeign = new RadioButton();
            radioLocal = new RadioButton();
            label2 = new Label();
            txtfees = new Label();
            btnCalculate = new Button();
            btnReset = new Button();
            btnExit = new Button();
            label3 = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(30, 27);
            label1.Name = "label1";
            label1.Size = new Size(107, 17);
            label1.TabIndex = 0;
            label1.Text = "Course Credit(s)";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // txtHours
            // 
            txtHours.Location = new Point(138, 25);
            txtHours.Name = "txtHours";
            txtHours.Size = new Size(116, 23);
            txtHours.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.FromArgb(192, 255, 255);
            groupBox1.Controls.Add(radioNormal);
            groupBox1.Controls.Add(radioProject);
            groupBox1.Location = new Point(50, 90);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(165, 128);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Course Type";
            // 
            // radioNormal
            // 
            radioNormal.AutoSize = true;
            radioNormal.Location = new Point(21, 74);
            radioNormal.Name = "radioNormal";
            radioNormal.Size = new Size(65, 19);
            radioNormal.TabIndex = 1;
            radioNormal.TabStop = true;
            radioNormal.Text = "Normal\r\n";
            radioNormal.UseVisualStyleBackColor = true;
            // 
            // radioProject
            // 
            radioProject.AutoSize = true;
            radioProject.Location = new Point(21, 30);
            radioProject.Name = "radioProject";
            radioProject.Size = new Size(126, 19);
            radioProject.TabIndex = 0;
            radioProject.TabStop = true;
            radioProject.Text = "Project / Internship\r\n";
            radioProject.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.Silver;
            groupBox2.Controls.Add(radioDistance);
            groupBox2.Controls.Add(radioSandwich);
            groupBox2.Controls.Add(radioRegular);
            groupBox2.Location = new Point(50, 268);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(165, 158);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Mode";
            // 
            // radioDistance
            // 
            radioDistance.AutoSize = true;
            radioDistance.Location = new Point(21, 121);
            radioDistance.Name = "radioDistance";
            radioDistance.Size = new Size(70, 19);
            radioDistance.TabIndex = 2;
            radioDistance.TabStop = true;
            radioDistance.Text = "Distance";
            radioDistance.UseVisualStyleBackColor = true;
            // 
            // radioSandwich
            // 
            radioSandwich.AutoSize = true;
            radioSandwich.Location = new Point(21, 74);
            radioSandwich.Name = "radioSandwich";
            radioSandwich.Size = new Size(76, 19);
            radioSandwich.TabIndex = 1;
            radioSandwich.TabStop = true;
            radioSandwich.Text = "Sandwich\r\n";
            radioSandwich.UseVisualStyleBackColor = true;
            // 
            // radioRegular
            // 
            radioRegular.AutoSize = true;
            radioRegular.Location = new Point(21, 30);
            radioRegular.Name = "radioRegular";
            radioRegular.Size = new Size(65, 19);
            radioRegular.TabIndex = 0;
            radioRegular.TabStop = true;
            radioRegular.Text = "Regular\r\n";
            radioRegular.UseVisualStyleBackColor = true;
            // 
            // listDepartment
            // 
            listDepartment.BackColor = Color.FromArgb(255, 128, 128);
            listDepartment.FormattingEnabled = true;
            listDepartment.ItemHeight = 15;
            listDepartment.Items.AddRange(new object[] { "Computer Science", "Nursing & Midwifery", "Business Administration", "Theology", "Development Studies", "Education" });
            listDepartment.Location = new Point(372, 32);
            listDepartment.Name = "listDepartment";
            listDepartment.Size = new Size(154, 154);
            listDepartment.TabIndex = 4;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = Color.Tomato;
            groupBox3.Controls.Add(radioForeign);
            groupBox3.Controls.Add(radioLocal);
            groupBox3.Location = new Point(363, 268);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(167, 145);
            groupBox3.TabIndex = 5;
            groupBox3.TabStop = false;
            groupBox3.Text = "Nationality";
            // 
            // radioForeign
            // 
            radioForeign.AutoSize = true;
            radioForeign.Location = new Point(35, 74);
            radioForeign.Name = "radioForeign";
            radioForeign.Size = new Size(92, 19);
            radioForeign.TabIndex = 2;
            radioForeign.TabStop = true;
            radioForeign.Text = "International";
            radioForeign.UseVisualStyleBackColor = true;
            // 
            // radioLocal
            // 
            radioLocal.AutoSize = true;
            radioLocal.Location = new Point(35, 30);
            radioLocal.Name = "radioLocal";
            radioLocal.Size = new Size(53, 19);
            radioLocal.TabIndex = 1;
            radioLocal.TabStop = true;
            radioLocal.Text = "Local";
            radioLocal.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(613, 43);
            label2.Name = "label2";
            label2.Size = new Size(117, 27);
            label2.TabIndex = 6;
            label2.Text = "TOTAL FEES";
            // 
            // txtfees
            // 
            txtfees.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtfees.Location = new Point(626, 71);
            txtfees.Name = "txtfees";
            txtfees.Size = new Size(104, 25);
            txtfees.TabIndex = 7;
            txtfees.Text = "0.00";
            txtfees.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnCalculate
            // 
            btnCalculate.BackColor = Color.Lime;
            btnCalculate.Location = new Point(637, 176);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(91, 34);
            btnCalculate.TabIndex = 8;
            btnCalculate.Text = "Calculate Fees";
            btnCalculate.UseVisualStyleBackColor = false;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = Color.Yellow;
            btnReset.Location = new Point(639, 242);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(91, 34);
            btnReset.TabIndex = 9;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = false;
            btnReset.Click += btnReset_Click;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.Red;
            btnExit.Location = new Point(639, 327);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(91, 34);
            btnExit.TabIndex = 10;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(375, 12);
            label3.Name = "label3";
            label3.Size = new Size(82, 17);
            label3.TabIndex = 11;
            label3.Text = "Department";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Aqua;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(btnExit);
            Controls.Add(btnReset);
            Controls.Add(btnCalculate);
            Controls.Add(txtfees);
            Controls.Add(label2);
            Controls.Add(groupBox3);
            Controls.Add(listDepartment);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(txtHours);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Valley View University Fees Calculator";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtHours;
        private GroupBox groupBox1;
        private RadioButton radioNormal;
        private RadioButton radioProject;
        private GroupBox groupBox2;
        private RadioButton radioDistance;
        private RadioButton radioSandwich;
        private RadioButton radioRegular;
        private ListBox listDepartment;
        private GroupBox groupBox3;
        private RadioButton radioForeign;
        private RadioButton radioLocal;
        private Label label2;
        private Label txtfees;
        private Button btnCalculate;
        private Button btnReset;
        private Button btnExit;
        private Label label3;
    }
}
