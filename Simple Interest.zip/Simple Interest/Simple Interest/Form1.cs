﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simple_Interest
{
    public partial class frmSimpleInterest : Form
    {
        public frmSimpleInterest()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal P;
            decimal R;
            int T;
            const int div = 100;
            decimal I;

            //Data input
            P = Decimal.Parse(txtPrincipal.Text);
            R = Decimal.Parse(txtRate.Text);
            T = int.Parse(txtTime.Text);

            //Processing
            I = (P * R * T) / div;

            //Output
            txtInterest.Text = I.ToString("C");
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtPrincipal.Text = "";
            txtRate.Text = "";
            txtTime.Text = "";
            txtInterest.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
