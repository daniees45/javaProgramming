import sys
import time

welcome = "WELCOME TO PRIME BANK"


print(welcome)
